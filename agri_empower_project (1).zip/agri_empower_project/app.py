import random
import os
from werkzeug.utils import secure_filename

from datetime import datetime, timedelta
from flask import jsonify

from flask import Flask, render_template, request, redirect, session
from flask_mysqldb import MySQL
from werkzeug.security import generate_password_hash, check_password_hash
from flask_mail import Mail, Message

app = Flask(__name__)
app.secret_key = "agri_secret_key"

# ---------------- MYSQL CONFIG ----------------
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'Saimohith1234'
app.config['MYSQL_DB'] = 'agri_empower'

mysql = MySQL(app)

# ------------------------------------------------
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'Sriramojusaimohith@gmail.com'
app.config['MAIL_PASSWORD'] = 'gluxygxgcssiukwu'
app.config['MAIL_DEFAULT_SENDER'] = 'AgriConnect <yourgmail@gmail.com>'

mail = Mail(app)


def send_email(to, subject, html_body):
    try:
        msg = Message(
            subject,
            recipients=[to],
            html=html_body
        )
        mail.send(msg)
        print("Email sent to", to)
    except Exception as e:
        print("Email Error:", e)




# ---------------- HOME ----------------
@app.route('/')
def index():
    return render_template('index.html')


# ---------------- REGISTER (NO ADMIN) ----------------
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = generate_password_hash(request.form['password'])
        role = request.form['role']

        if role == 'admin':
            return "Unauthorized role"

        cursor = mysql.connection.cursor()
        cursor.execute(
            "INSERT INTO users (name, email, password, role) VALUES (%s,%s,%s,%s)",
            (name, email, password, role)
        )
        mysql.connection.commit()
        cursor.close()

        return redirect('/login')

    return render_template('register.html')


# ---------------- LOGIN ----------------
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        cursor = mysql.connection.cursor()
        cursor.execute("SELECT * FROM users WHERE email=%s", (email,))
        user = cursor.fetchone()
        cursor.close()

        if user and check_password_hash(user[3], password):
            session['user_id'] = user[0]
            session['role'] = user[4]
            return redirect('/dashboard')

        return "Invalid credentials"

    return render_template('login.html')


# ---------------- DASHBOARD ----------------
@app.route('/dashboard')
def dashboard():
    role = session.get('role')

    if role == 'farmer':
        return render_template('farmer_dashboard.html')
    elif role == 'buyer':
        return render_template('buyer_dashboard.html')
    elif role == 'admin':
        return render_template('admin_dashboard.html')
    else:
        return redirect('/login')


# ================= FARMER MODULE =================

@app.route('/add_crop', methods=['GET', 'POST'])
def add_crop():
    if session.get('role') != 'farmer':
        return "Unauthorized access"

    if request.method == 'POST':
        crop = request.form['crop']
        quantity = int(request.form['quantity'])
        price = float(request.form['price'])

        image_file = request.files.get('image')

        image_name = 'default_crop.jpg'

        if image_file and image_file.filename != '':
            filename = secure_filename(image_file.filename)
            image_name = f"{session['user_id']}_{filename}"

            image_path = os.path.join('static', 'crop_images', image_name)
            image_file.save(image_path)

        cursor = mysql.connection.cursor()
        cursor.execute("""
            INSERT INTO crops (farmer_id, crop_name, quantity, price, status, image)
            VALUES (%s,%s,%s,%s,'Available',%s)
        """, (session['user_id'], crop, quantity, price, image_name))

        mysql.connection.commit()
        cursor.close()

        return redirect('/dashboard')

    return render_template('add_crop.html')




@app.route('/my_crops')
def my_crops():
    if session.get('role') != 'farmer':
        return "Unauthorized access"

    cursor = mysql.connection.cursor()
    cursor.execute("SELECT * FROM crops WHERE farmer_id=%s", (session['user_id'],))
    crops = cursor.fetchall()
    cursor.close()

    return render_template('farmer_crops.html', crops=crops)


@app.route('/edit_crop/<int:crop_id>', methods=['GET', 'POST'])
def edit_crop(crop_id):
    if session.get('role') != 'farmer':
        return "Unauthorized access"

    cursor = mysql.connection.cursor()
    cursor.execute(
        "SELECT * FROM crops WHERE id=%s AND farmer_id=%s",
        (crop_id, session['user_id'])
    )
    crop = cursor.fetchone()

    if not crop:
        cursor.close()
        return "Crop not found"

    if crop[5] == 'Sold':
        cursor.close()
        return "Cannot edit sold crop"

    if request.method == 'POST':
        quantity = int(request.form['quantity'])
        price = float(request.form['price'])

        cursor.execute(
            "UPDATE crops SET quantity=%s, price=%s WHERE id=%s",
            (quantity, price, crop_id)
        )
        mysql.connection.commit()
        cursor.close()
        return redirect('/my_crops')

    cursor.close()
    return render_template('edit_crop.html', crop=crop)


@app.route('/apply_loan', methods=['GET', 'POST'])
def apply_loan():
    if session.get('role') != 'farmer':
        return "Unauthorized access"

    if request.method == 'POST':
        amount = float(request.form['amount'])

        cursor = mysql.connection.cursor()
        cursor.execute(
            "INSERT INTO loans (farmer_id, amount, status) VALUES (%s,%s,'Pending')",
            (session['user_id'], amount)
        )
        mysql.connection.commit()
        cursor.close()

        return redirect('/dashboard')

    return render_template('apply_loan.html')


# ================= BUYER MODULE =================

@app.route('/view_crops')
def view_crops():
    if session.get('role') != 'buyer':
        return "Unauthorized access"

    cursor = mysql.connection.cursor()
    cursor.execute("SELECT * FROM crops WHERE status='Available' AND quantity > 0")
    crops = cursor.fetchall()
    cursor.close()

    return render_template('view_crops.html', crops=crops)


# ---------- 3.1 ADD TO CART ----------
@app.route('/add_to_cart/<int:crop_id>', methods=['POST'])
def add_to_cart(crop_id):
    if session.get('role') != 'buyer':
        return "Unauthorized access"

    qty = int(request.form['quantity'])
    buyer_id = session['user_id']

    cursor = mysql.connection.cursor()
    cursor.execute(
        "SELECT quantity FROM crops WHERE id=%s AND status='Available'",
        (crop_id,)
    )
    crop = cursor.fetchone()

    if not crop or qty > crop[0]:
        cursor.close()
        return redirect('/view_crops')

    cursor.execute(
        "INSERT INTO cart (buyer_id, crop_id, quantity) VALUES (%s,%s,%s)",
        (buyer_id, crop_id, qty)
    )

    mysql.connection.commit()
    cursor.close()
    return redirect('/cart')


# ---------- 3.2 VIEW CART ----------
@app.route('/cart')
def cart():
    if session.get('role') != 'buyer':
        return "Unauthorized access"

    cursor = mysql.connection.cursor()
    cursor.execute("""
        SELECT cart.id, crops.crop_name, cart.quantity, crops.price
        FROM cart
        JOIN crops ON cart.crop_id = crops.id
        WHERE cart.buyer_id=%s
    """, (session['user_id'],))

    items = cursor.fetchall()

    # ✅ CALCULATE GRAND TOTAL
    grand_total = 0
    for item in items:
        qty = item[2]
        price = item[3]
        grand_total += qty * price

    cursor.close()

    return render_template(
        'cart.html',
        items=items,
        grand_total=grand_total
    )


# -------- UPDATE CART QUANTITY --------
@app.route('/update_cart/<int:cart_id>', methods=['POST'])
def update_cart(cart_id):
    if session.get('role') != 'buyer':
        return "Unauthorized access"

    action = request.form['action']
    cursor = mysql.connection.cursor()

    # Get cart item
    cursor.execute("""
        SELECT cart.quantity, crops.quantity
        FROM cart
        JOIN crops ON cart.crop_id = crops.id
        WHERE cart.id=%s
    """, (cart_id,))
    item = cursor.fetchone()

    if not item:
        cursor.close()
        return redirect('/cart')

    cart_qty, stock_qty = item

    if action == 'increase' and cart_qty < stock_qty:
        cart_qty += 1
    elif action == 'decrease' and cart_qty > 1:
        cart_qty -= 1

    cursor.execute(
        "UPDATE cart SET quantity=%s WHERE id=%s",
        (cart_qty, cart_id)
    )

    mysql.connection.commit()
    cursor.close()
    return redirect('/cart')


# -------- REMOVE ITEM FROM CART --------
@app.route('/remove_from_cart/<int:cart_id>')
def remove_from_cart(cart_id):
    if session.get('role') != 'buyer':
        return "Unauthorized access"

    cursor = mysql.connection.cursor()
    cursor.execute("DELETE FROM cart WHERE id=%s", (cart_id,))
    mysql.connection.commit()
    cursor.close()

    return redirect('/cart')




# ---------- 5.1 CHECKOUT ----------
@app.route('/checkout', methods=['GET', 'POST'])
def checkout():
    if session.get('role') != 'buyer':
        return "Unauthorized access"

    cursor = mysql.connection.cursor()

    cursor.execute("""
        SELECT 
            crops.crop_name, 
            cart.quantity, 
            crops.price
        FROM cart
        JOIN crops ON cart.crop_id = crops.id
        WHERE cart.buyer_id = %s
    """, (session['user_id'],))

    items = cursor.fetchall()

    grand_total = 0
    for item in items:
        grand_total += item[1] * item[2]   # quantity * price

    cursor.close()

    return render_template(
        "checkout.html",
        items=items,
        grand_total=grand_total
    )



# ---------- PLACE ORDER ----------
@app.route('/place_order', methods=['POST'])
def place_order():
    if session.get('role') != 'buyer':
        return "Unauthorized access"

    payment_method = request.form['payment_method']
    upi_id = request.form.get('upi_id')

    # ✅ UPI VALIDATION
    if payment_method == 'UPI':
        if not upi_id or '@' not in upi_id:
            return "Invalid UPI ID"

    buyer_id = session['user_id']
    cursor = mysql.connection.cursor()

    cursor.execute(
        "SELECT crop_id, quantity FROM cart WHERE buyer_id=%s",
        (buyer_id,)
    )
    cart_items = cursor.fetchall()

    for crop_id, qty in cart_items:
        cursor.execute(
            "SELECT quantity, price FROM crops WHERE id=%s",
            (crop_id,)
        )
        stock, price = cursor.fetchone()

        total = qty * price

        cursor.execute(
            "INSERT INTO orders (buyer_id, crop_id, quantity, total_price, status) "
            "VALUES (%s,%s,%s,%s,'Placed')",
            (buyer_id, crop_id, qty, total)
        )

        remaining = stock - qty
        if remaining > 0:
            cursor.execute(
                "UPDATE crops SET quantity=%s WHERE id=%s",
                (remaining, crop_id)
            )
        else:
            cursor.execute(
                "UPDATE crops SET quantity=0, status='Sold' WHERE id=%s",
                (crop_id,)
            )

    cursor.execute("DELETE FROM cart WHERE buyer_id=%s", (buyer_id,))
    mysql.connection.commit()
    cursor.execute("SELECT name, email FROM users WHERE id=%s", (buyer_id,))
    buyer = cursor.fetchone()

    html_body = f"""
    <h2 style="color:green;">Order Placed Successfully 🌱</h2>
    <p>Hello <b>{buyer[0]}</b>,</p>
    <p>Your order has been placed successfully on <b>Agro Connect</b>.</p>
    <p><b>Payment Method:</b> {payment_method}</p>
    <p>Status: <b>Placed</b></p>
    <hr>
    <p>Thank you for supporting farmers directly!</p>
    """

    send_email(buyer[1], "Agro Connect – Order Placed", html_body)

    cursor.close()

    return redirect('/order_success')








@app.route('/buyer_orders')
def buyer_orders():
    if session.get('role') != 'buyer':
        return "Unauthorized access"

    cursor = mysql.connection.cursor()
    cursor.execute("""
        SELECT orders.id,
               crops.crop_name,
               orders.quantity,
               orders.total_price,
               orders.status,
               orders.order_date
        FROM orders
        JOIN crops ON orders.crop_id = crops.id
        WHERE orders.buyer_id=%s
        ORDER BY orders.order_date DESC
    """, (session['user_id'],))

    orders = cursor.fetchall()
    cursor.close()

    return render_template('buyer_orders.html', orders=orders)



@app.route('/cancel_order/<int:order_id>')
def cancel_order(order_id):
    if session.get('role') != 'buyer':
        return "Unauthorized access"

    buyer_id = session['user_id']
    cursor = mysql.connection.cursor()

    # Get order details
    cursor.execute("""
        SELECT crop_id, quantity, status
        FROM orders
        WHERE id=%s AND buyer_id=%s
    """, (order_id, buyer_id))
    order = cursor.fetchone()

    if not order or order[2] != 'Placed':
        cursor.close()
        return redirect('/buyer_orders')

    crop_id, qty, status = order

    # Restore crop quantity
    cursor.execute(
        "UPDATE crops SET quantity = quantity + %s, status='Available' WHERE id=%s",
        (qty, crop_id)
    )

    # Cancel order
    cursor.execute(
        "UPDATE orders SET status='Cancelled' WHERE id=%s",
        (order_id,)
    )

    mysql.connection.commit()
    cursor.execute("SELECT name, email FROM users WHERE id=%s", (buyer_id,))
    buyer = cursor.fetchone()

    html_body = f"""
    <h2 style="color:red;">Order Cancelled ❌</h2>
    <p>Hello <b>{buyer[0]}</b>,</p>
    <p>Your order <b>#{order_id}</b> has been cancelled successfully.</p>
    <p>If payment was done, refund will be processed.</p>
    <hr>
    <p>AgriConnect Team</p>
    """

    send_email(buyer[1], "Agro Connect – Order Cancelled", html_body)

    cursor.close()

    return redirect('/buyer_orders')


# ================= ADMIN MODULE =================

@app.route('/admin_analytics')
def admin_analytics():
    if session.get('role') != 'admin':
        return "Unauthorized access"

    cursor = mysql.connection.cursor()

    cursor.execute("SELECT COUNT(*) FROM users WHERE role='farmer'")
    total_farmers = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM users WHERE role='buyer'")
    total_buyers = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM orders")
    total_orders = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM crops WHERE status='Sold'")
    crops_sold = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM loans WHERE status='Approved'")
    approved_loans = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM loans WHERE status='Pending'")
    pending_loans = cursor.fetchone()[0]

    cursor.close()

    return render_template(
        'admin_analytics.html',
        total_farmers=total_farmers,
        total_buyers=total_buyers,
        total_orders=total_orders,
        crops_sold=crops_sold,
        approved_loans=approved_loans,
        pending_loans=pending_loans
    )


    # -------- ADMIN: APPROVE LOAN --------
@app.route('/approve_loan/<int:loan_id>')
def approve_loan(loan_id):
    if session.get('role') != 'admin':
        return "Unauthorized access"

    cursor = mysql.connection.cursor()

    # Update status
    cursor.execute(
        "UPDATE loans SET status='Approved' WHERE id=%s",
        (loan_id,)
    )

    # Get farmer details
    cursor.execute("""
        SELECT users.email, users.name, loans.amount
        FROM loans
        JOIN users ON loans.farmer_id = users.id
        WHERE loans.id=%s
    """, (loan_id,))
    farmer = cursor.fetchone()

    mysql.connection.commit()
    cursor.close()

    farmer_email, farmer_name, amount = farmer

    html_body = f"""
    <h2 style="color:green;">Loan Approved ✅</h2>
    <p>Hello <b>{farmer_name}</b>,</p>

    <p>Good news! Your loan request has been <b>APPROVED</b>.</p>

    <p><b>Loan Amount:</b> ₹{amount}</p>
    <p>Status: Approved</p>

    <p>Please check your dashboard for details.</p>

    <hr>
    <p>Agro Connect – Empowering Farmers 🌱</p>
    """

    send_email(
        farmer_email,
        "AgriConnect – Loan Approved",
        html_body
    )

    return redirect('/admin_loans')


# -------- ADMIN: REJECT LOAN --------
@app.route('/reject_loan/<int:loan_id>')
def reject_loan(loan_id):
    if session.get('role') != 'admin':
        return "Unauthorized access"

    cursor = mysql.connection.cursor()

    cursor.execute(
        "UPDATE loans SET status='Rejected' WHERE id=%s",
        (loan_id,)
    )

    cursor.execute("""
        SELECT users.email, users.name, loans.amount
        FROM loans
        JOIN users ON loans.farmer_id = users.id
        WHERE loans.id=%s
    """, (loan_id,))
    farmer = cursor.fetchone()

    mysql.connection.commit()
    cursor.close()

    farmer_email, farmer_name, amount = farmer

    html_body = f"""
    <h2 style="color:red;">Loan Rejected ❌</h2>
    <p>Hello <b>{farmer_name}</b>,</p>

    <p>We regret to inform you that your loan request was <b>REJECTED</b>.</p>

    <p><b>Loan Amount:</b> ₹{amount}</p>

    <p>You may reapply with updated details.</p>

    <hr>
    <p>Agro Connect Support Team</p>
    """

    send_email(
        farmer_email,
        "AgriConnect – Loan Rejected",
        html_body
    )

    return redirect('/admin_loans')


# ---------------- ADMIN: VIEW LOANS ----------------
@app.route('/admin_loans')
def admin_loans():
    if session.get('role') != 'admin':
        return "Unauthorized access"

    cursor = mysql.connection.cursor()
    cursor.execute("""
        SELECT loans.id, users.name, loans.amount, loans.status, loans.created_at
        FROM loans
        JOIN users ON loans.farmer_id = users.id
        ORDER BY loans.created_at DESC
    """)
    loans = cursor.fetchall()
    cursor.close()

    return render_template('admin_loans.html', loans=loans)

# -------- ADMIN: MARK CROP AS SOLD --------
@app.route('/mark_sold/<int:crop_id>')
def mark_sold(crop_id):
    if session.get('role') != 'admin':
        return "Unauthorized access"

    cursor = mysql.connection.cursor()
    cursor.execute(
        "UPDATE crops SET status='Sold', quantity=0 WHERE id=%s",
        (crop_id,)
    )
    mysql.connection.commit()
    cursor.close()

    return redirect('/admin_crops')




# ---------------- ADMIN: VIEW CROPS ----------------
@app.route('/admin_crops')
def admin_crops():
    if session.get('role') != 'admin':
        return "Unauthorized access"

    cursor = mysql.connection.cursor()
    cursor.execute("""
        SELECT crops.id, users.name, crops.crop_name,
               crops.quantity, crops.price, crops.status
        FROM crops
        JOIN users ON crops.farmer_id = users.id
        ORDER BY crops.id DESC
    """)
    crops = cursor.fetchall()
    cursor.close()

    return render_template('admin_crops.html', crops=crops)




# ---------------- LOGOUT ----------------
@app.route('/logout')
def logout():
    session.clear()
    return redirect('/login')

@app.route('/order_success')
def order_success():
    if session.get('role') != 'buyer':
        return "Unauthorized access"

    return render_template('order_success.html')


@app.route('/chat/<int:user_id>')
def chat(user_id):
    if 'user_id' not in session:
        return redirect('/login')

    my_id = session['user_id']
    cursor = mysql.connection.cursor()

    cursor.execute("""
        SELECT sender_id, receiver_id, message, created_at
        FROM messages
        WHERE (sender_id=%s AND receiver_id=%s)
           OR (sender_id=%s AND receiver_id=%s)
        ORDER BY created_at
    """, (my_id, user_id, user_id, my_id))

    messages = cursor.fetchall()

    cursor.execute("SELECT name FROM users WHERE id=%s", (user_id,))
    other_user = cursor.fetchone()[0]

    cursor.close()

    return render_template(
        'chat.html',
        messages=messages,
        other_user=other_user,
        other_id=user_id,
        my_id=my_id
    )

@app.route('/send_message', methods=['POST'])
def send_message():
    sender = session['user_id']
    receiver = request.form['receiver_id']
    message = request.form['message']

    cursor = mysql.connection.cursor()
    cursor.execute(
        "INSERT INTO messages (sender_id, receiver_id, message) VALUES (%s,%s,%s)",
        (sender, receiver, message)
    )
    mysql.connection.commit()
    cursor.close()

    return redirect(f'/chat/{receiver}')

@app.route('/my_messages')
def my_messages():
    if session.get('role') != 'farmer':
        return "Unauthorized access"

    farmer_id = session['user_id']
    cursor = mysql.connection.cursor()

    cursor.execute("""
        SELECT DISTINCT users.id, users.name
        FROM messages
        JOIN users ON users.id = messages.sender_id
        WHERE messages.receiver_id = %s
    """, (farmer_id,))

    buyers = cursor.fetchall()
    cursor.close()

    return render_template('my_messages.html', buyers=buyers)

@app.route('/test_mail')
def test_mail():
    send_email(
        to='YOUR_PERSONAL_EMAIL@gmail.com',
        subject='AgriConnect Test Mail',
        html_body="""
        <h2>Mail Test Successful ✅</h2>
        <p>If you see this, email is working.</p>
        """
    )
    return "Mail sent"




@app.route('/ai_chat', methods=['POST'])
def ai_chat():
    data = request.get_json()
    user_msg = data.get('message', '').lower()

    # SIMPLE AI LOGIC (Rule-based)
    if "buy" in user_msg:
        reply = "To buy crops, go to View Crops → select quantity → add to cart → checkout."
    elif "loan" in user_msg:
        reply = "Farmers can apply for loans from Dashboard → Apply Loan. Admin will review it."
    elif "order" in user_msg:
        reply = "You can view order status in My Orders section."
    elif "cart" in user_msg:
        reply = "Click the cart icon to view items added to your cart."
    elif "hello" in user_msg or "hi" in user_msg:
        reply = "Hello 👋 I'm AgriConnect AI. How can I help you today?"
    else:
        reply = "I'm here to help with orders, crops, loans, and platform usage."



@app.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form['email']
        otp = str(random.randint(100000, 999999))
        expiry = datetime.now() + timedelta(minutes=10)

        cursor = mysql.connection.cursor()
        cursor.execute(
            "SELECT id FROM users WHERE email=%s", (email,)
        )
        user = cursor.fetchone()

        if not user:
            cursor.close()
            return "Email not registered"

        cursor.execute(
            "UPDATE users SET reset_otp=%s, otp_expiry=%s WHERE email=%s",
            (otp, expiry, email)
        )
        mysql.connection.commit()
        cursor.close()

        send_email(
            email,
            "AgriConnect – Password Reset OTP",
            f"""
            <h2>Password Reset</h2>
            <p>Your OTP is:</p>
            <h1>{otp}</h1>
            <p>Valid for 10 minutes.</p>
            """
        )

        session['reset_email'] = email
        return redirect('/verify_otp')

    return render_template('forgot_password.html')

@app.route('/verify_otp', methods=['GET', 'POST'])
def verify_otp():
    if request.method == 'POST':
        otp_entered = request.form['otp']
        email = session.get('reset_email')

        cursor = mysql.connection.cursor()
        cursor.execute("""
            SELECT reset_otp, otp_expiry 
            FROM users WHERE email=%s
        """, (email,))
        data = cursor.fetchone()
        cursor.close()

        if not data:
            return "Session expired"

        otp_db, expiry = data

        if otp_db != otp_entered or datetime.now() > expiry:
            return "Invalid or expired OTP"

        return redirect('/reset_password')

    return render_template('verify_otp.html')


@app.route('/resend_otp', methods=['POST'])
def resend_otp():
    email = request.form['email']

    cursor = mysql.connection.cursor()
    cursor.execute(
        "SELECT id, name FROM users WHERE email=%s",
        (email,)
    )
    user = cursor.fetchone()

    if not user:
        cursor.close()
        return "Email not found"

    user_id, name = user

    # 🔐 Generate NEW OTP
    otp = str(random.randint(100000, 999999))
    expiry = datetime.now() + timedelta(minutes=5)

    cursor.execute("""
        UPDATE users 
        SET reset_otp=%s, otp_expiry=%s 
        WHERE id=%s
    """, (otp, expiry, user_id))

    mysql.connection.commit()
    cursor.close()

    # 📧 Send OTP Email
    html_body = f"""
    <h2>AgriConnect – OTP Resent 🔐</h2>
    <p>Hello <b>{name}</b>,</p>

    <p>Your new OTP for password reset is:</p>
    <h1 style="letter-spacing:3px;">{otp}</h1>

    <p>This OTP is valid for <b>5 minutes</b>.</p>

    <p>If you didn’t request this, please ignore.</p>

    <hr>
    <p>AgriConnect Security Team 🌱</p>
    """

    send_email(
        email,
        "AgriConnect – Resent OTP",
        html_body
    )

    return redirect(f"/verify_otp?email={email}")



@app.route('/reset_password', methods=['GET', 'POST'])
def reset_password():
    email = session.get('reset_email')
    if not email:
        return redirect('/login')

    if request.method == 'POST':
        new_password = generate_password_hash(request.form['password'])

        cursor = mysql.connection.cursor()
        cursor.execute("""
            UPDATE users 
            SET password=%s, reset_otp=NULL, otp_expiry=NULL
            WHERE email=%s
        """, (new_password, email))
        mysql.connection.commit()
        cursor.close()

        session.pop('reset_email', None)
        return redirect('/login')

    return render_template('reset_password.html')








if __name__ == '__main__':
    app.run(debug=True)
