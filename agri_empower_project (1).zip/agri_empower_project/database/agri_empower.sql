
CREATE DATABASE agri_empower;
USE agri_empower;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    password VARCHAR(255),
    role ENUM('farmer','buyer','admin')
);

CREATE TABLE crops (
    id INT AUTO_INCREMENT PRIMARY KEY,
    farmer_id INT,
    crop_name VARCHAR(100),
    quantity INT,
    price DECIMAL(10,2),
    status VARCHAR(50)
);

CREATE TABLE loans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    farmer_id INT,
    amount DECIMAL(10,2),
    status VARCHAR(50),
    applied_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
